#include "Bot.hpp"

Bot::Bot(){}